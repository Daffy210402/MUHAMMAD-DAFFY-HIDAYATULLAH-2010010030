
<?php
$title 	= " Laporan Sasaran Kinerja Pegawai";

include '../modul/pdf/head.php';
$html .= "
<table id='page-length-option' border='1' style='width:100%;' class='display'>
<thead>
<tr>	
<th>Rangking</th>
<th>Nama Pegawai</th>
<th>NIP</th>
<th>Jabatan</th>
<th>Unit Kerja</th>
<th>Nilai SKP</th>
<th>Orientasi Pelayanan</th>
<th>Integritas</th>
<th>Komitmen</th>
<th>Disiplin</th>
<th>Kerjasama</th>
<th>Kepemimpinan</th>
<th>Total Nilai</th>
</tr>
</thead>
<tbody>
";

$pegawai_nilai = array();

$sql = mysqli_query($koneksi,"SELECT * FROM skp
    JOIN user USING(id_user)
    JOIN jabatan USING(id_jabatan)
    JOIN unitkerja USING(id_unitkerja)
    WHERE tanggal_skp BETWEEN '$dari' AND '$sampai'
    ");

while ($data = mysqli_fetch_array($sql)) {
    $total_nilai = 
        ($data['nilai_skp'] * 0.2) +
        ($data['orientasi_pelayanan'] * 0.15) +
        ($data['integritas'] * 0.15) +
        ($data['komitmen'] * 0.15) +
        ($data['disiplin'] * 0.15) +
        ($data['kerjasama'] * 0.1) +
        ($data['kepemimpinan'] * 0.1);
    
    $pegawai_nilai[] = array(
        'nama' => $data['nama_pengguna'],
        'nip' => $data['nip'],
        'jabatan' => $data['nama_jabatan'],
        'unit_kerja' => $data['nama_unitkerja'],
        'nilai_skp' => $data['nilai_skp'],
        'orientasi_pelayanan' => $data['orientasi_pelayanan'],
        'integritas' => $data['integritas'],
        'komitmen' => $data['komitmen'],
        'disiplin' => $data['disiplin'],
        'kerjasama' => $data['kerjasama'],
        'kepemimpinan' => $data['kepemimpinan'],
        'total_nilai' => $total_nilai
    );
}

usort($pegawai_nilai, function($a, $b) {
    return $b['total_nilai'] <=> $a['total_nilai'];
});

foreach ($pegawai_nilai as $index => $pegawai) {
    $rangking = $index + 1;
    $html .= "<tr>
    <td>Rangking-".$rangking."</td>
    <td>".$pegawai['nama']."</td>
    <td>".$pegawai['nip']."</td>
    <td>".$pegawai['jabatan']."</td>
    <td>".$pegawai['unit_kerja']."</td>
    <td>".$pegawai['nilai_skp']."</td>
    <td>".$pegawai['orientasi_pelayanan']."</td>
    <td>".$pegawai['integritas']."</td>
    <td>".$pegawai['komitmen']."</td>
    <td>".$pegawai['disiplin']."</td>
    <td>".$pegawai['kerjasama']."</td>
    <td>".$pegawai['kepemimpinan']."</td>
    <td>".number_format($pegawai['total_nilai'], 2)."</td>
    </tr>";
}

$html .="</tbody>
</table>";
include '../modul/pdf/foot2.php';
?>
